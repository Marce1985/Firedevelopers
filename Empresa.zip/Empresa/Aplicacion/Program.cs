﻿using System;

namespace Aplicacion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Funcionando perfecto!");
        }
    }
}
