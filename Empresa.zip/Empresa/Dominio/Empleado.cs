namespace Dominio
{
    public class Empleado
    {
        public string id { get; set; }
        public float sueldo_bruto { get; set; }
        
    }
}