namespace Dominio
{
    public class Directivo
    {
        public string id { get; set; }
        
    }
}