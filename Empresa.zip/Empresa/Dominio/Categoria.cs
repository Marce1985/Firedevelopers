namespace Dominio
{
    public class Categoria
    {
        public int id { get; set; }
        public string descripcion { get; set; }
        
    }
}
