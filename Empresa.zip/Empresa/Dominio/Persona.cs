namespace Dominio
{
    public class Persona
    {
        public string id { get; set; }
        public string nombre { get; set; }
        public int edad { get; set; }
        public string telefono { get; set; }
        public string direccion { get; set; }
        
        
    }
}