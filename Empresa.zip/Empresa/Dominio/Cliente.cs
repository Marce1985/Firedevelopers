namespace Dominio
{
    public class Cliente
    {
        public string id { get; set; }
        public string telefono { get; set; }
        
    }
}